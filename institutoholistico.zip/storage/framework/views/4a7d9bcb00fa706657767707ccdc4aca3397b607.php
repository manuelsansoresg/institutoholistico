<?php $__env->startSection('title', 'Carrusel'); ?>

<?php $__env->startSection('content_header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/summernote/summernote-bs4.css')); ?>">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    Carrusel
                    <small>Imagenes</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="/admin/carrusel">Carrusel</a></li>
                    <li class="breadcrumb-item active">Imagenes</li>

                </ol>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 bg-white">
                <form method="post" action="/admin/carrusel/images/<?php echo e($set_lang); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if($images !== null && count($images) <= 6): ?>
                        <div class="row justify-content-center">
                            <div class="col-12 col-md-6 mt-3">
                                <div class="mb-3">
                                    <label for="formGroupExampleInput" class="form-label">Agregar imagen</label>
                                    <input type="file" name="imagen" class="form-control">
                                </div>
                                <div class="mb-3 text-right">
                                    <button class="btn btn-primary">Agregar</button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </form>
            </div>

        </div>
        <?php if($images !== null): ?>
            <div class="row">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-2">
                        <div class="text-center">
                            <img class="img-fluid" src="<?php echo e(asset('img/carrusel') . '/' . 'thumb_' . $image->image); ?>"
                                alt="">
                        </div>
                        <div class="">
                            <p>
                                <br>
                                <a href="/admin/carrusel/image/destroy/<?php echo e($image->id); ?>/<?php echo e($set_lang); ?>"
                                    class="btn btn-danger btn-block">Borrar</a>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/web/laravel/institutoholistico/resources/views/admin/carrusel/images.blade.php ENDPATH**/ ?>