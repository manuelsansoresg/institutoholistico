<!-- HEADER -->
<table class="head-wrap" style="width: 100%; background-color: #717CFF">
    <tr>
        <td></td>
        <td class="header container">

            <div class="content">
                <table>
                    <tr>
                        <td>
                            <img src="<?php echo e(asset('img/gallery/logo.png')); ?>" width="100" alt="">

                        </td>
                    </tr>
                </table>
            </div>

        </td>
        <td></td>
    </tr>
</table><!-- /HEADER -->
<?php /**PATH /home/manuel/web/laravel/institutoholistico/resources/views/mail/sections/header.blade.php ENDPATH**/ ?>