<?php $__env->startSection('title', 'Cabeceras'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    Cabeceras
                    <small>Listado</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item active">Cabeceras</li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-10 bg-white">
                <div class="box py-3 px-3">

                    <!-- /.box-header -->
                    <div class="box-body">
                        
                        <div class="col-md-12">
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <table id="dataTable" class="table table-bordered table-responsive">
                            <thead>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Imagen</th>
                                    <th>Título</th>
                                    <th>Descripción</th>
                                    <th>Lenguaje</th>
                                    <th style="width:150px"></th>
                                </tr>
                            </thead>

                            <?php if($es_sections !== null): ?>
                                <?php $__currentLoopData = $es_sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $es_section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $images = get_images($es_section['section_id'], false, 0); ?>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($es_section['id']); ?></td>
                                            <td>
                                                <?php if($images !== null): ?>
                                                    <img class="preview"
                                                        src="<?php echo e(asset('img/cabecera/') . '/' . $images->image); ?>" alt="">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $es_section['title']; ?></td>
                                            <td> <?php echo Str::limit($es_section['description']['description'], 40); ?>

                                            </td>
                                            <td>
                                                <?php if($es_section['lang'] == 'es'): ?>
                                                    <span class="badge bg-blue"><?php echo e($es_section['lang']); ?></span>
                                                <?php endif; ?>
                                                <?php if($es_section['lang'] == 'en'): ?>
                                                    <span class="badge bg-green"><?php echo e($es_section['lang']); ?></span>
                                                <?php endif; ?>
                                                <?php if($es_section['lang'] == 'fr'): ?>
                                                    <span class="badge bg-purple"><?php echo e($es_section['lang']); ?></span>
                                                <?php endif; ?>

                                            </td>

                                            <td>
                                                <?php echo e(Form::open(['route' => ['cabecera.destroy', $es_section['id']], 'class' => 'form-inline', 'method' => 'DELETE'])); ?>

                                                <a href="/#cabecera" target="_blank" class="btn btn-success btn-block"><i
                                                        class="far fa-eye"></i> </a>

                                                <a href="<?php echo e(route('cabecera.edit', $es_section['lang'])); ?>"
                                                    class="btn btn-primary btn-block">
                                                    <i class="far fa-edit"></i>
                                                </a>


                                                <?php echo e(Form::close()); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </table>
                        <div class="col-md-12 text-center">

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor/datatables-plugins/responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script>
        $(function() {

            $('#dataTable').DataTable({
                'paging': true,
                'lengthChange': false,
                'searching': false,
                'ordering': false,
                'info': true,
                'autoWidth': false,
                "scrollX": true,
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Entradas",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/web/laravel/institutoholistico/resources/views/admin/cabeceras/index.blade.php ENDPATH**/ ?>