<?php
return [
    'error_title' => 'Error',
    'error_description' => 'Fields marked with * are required',
    'ok_title ' => 'Thanks',
    'ok_description ' => 'We will contact you soon.',
];
