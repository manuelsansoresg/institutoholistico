<?php
return [
    'error_title' => 'Erreur ',
    'error_description' => 'Les champs marqués d\'un * sont obligatoire',

    'ok_title ' => 'Merci beaucoup',
    'ok_description ' => 'Très bientôt, nous vous contacterons.',
];
