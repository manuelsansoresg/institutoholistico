<?php $__env->startSection('title', 'Terapias'); ?>

<?php $__env->startSection('content_header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/summernote/summernote-bs4.css')); ?>">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    Talleres
                    <small>Listado</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="/admin/talleres">Talleres</a></li>
                    <li class="breadcrumb-item active">Editar</li>

                </ol>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-12 bg-white">
                <div class="box py-3 px-3">
                    <div class="box-header with-border">
                        <h3 class="box-title">Editar</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <?php echo e(Form::open(['route' => ['talleres.update', $section_id], 'method' => 'PUT', 'files' => true])); ?>


                        <div class="container">
                            <div class="row">
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Título</label>
                                        <textarea name="titulo" id="titulo"><?php echo $es_sections[0]->description; ?></textarea>


                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('titulo')); ?></span>
                                        <?php endif; ?>
                                    </div>


                                </div>
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Descripción</label>
                                        <textarea name="descripcion" id="descripcion"><?php echo $es_sections[1]->description; ?></textarea>

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('descripcion')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>


                                <br>
                                <div class="col-md-11 box-header with-border">
                                    <h3 class="box-title">Imágenes</h3>
                                </div>
                                <div class="col-md-4">
                                    <br> <br>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Imagen</label>
                                        <?php if($image == ''): ?>
                                            <input type="file" name="imagen" class="form-control">
                                            <?php if($errors): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('imagen')); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12"> </div>
                                <div class="col-md-2">
                                    <?php if($image != ''): ?>
                                        <img src="<?php echo e(asset('img/talleres') . '/' . 'thumb_' . $image->image); ?>" alt="">
                                        <div class="pull-right">
                                            <p>
                                                <br>
                                                <a href="/admin/talleres/image/destroy/<?php echo e($image->id); ?>/<?php echo e($set_lang); ?>"
                                                    class="btn btn-danger ">Borrar</a>
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-12"> </div>
                                


                            </div>
                            <div class="row">
                                <div class="col-12 text-right">
                                    <div class="form-group">
                                        <button class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="lang" value="<?php echo e($set_lang); ?>">
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor_assets/summernote/summernote.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#titulo').summernote({
                height: 50,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'black', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });

            $('#descripcion').summernote({
                height: 200,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });

            $('#descripcion2').summernote({
                height: 200,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/web/laravel/institutoholistico/resources/views/admin/talleres/edit.blade.php ENDPATH**/ ?>