<?php
return [
    'error_title' => 'Error',
    'error_description' => 'Los campos marcados con * son obligatorios',
    'ok_title ' => '¡Gracias!',
    'ok_description ' => 'Muy pronto nos pondremos en contacto contigo.',
];
