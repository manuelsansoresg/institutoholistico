<?php
return [
    'about' => 'About Us',
    'criteria' => 'Investment  Criteria',
    'contact' => 'Contact Us',
    'team' => 'The Team',
    'transaction' => 'Transaction',

];
