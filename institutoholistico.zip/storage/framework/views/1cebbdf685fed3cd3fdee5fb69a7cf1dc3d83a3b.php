<?php $__env->startSection('title', 'Contacto'); ?>

<?php $__env->startSection('content_header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/summernote/summernote-bs4.css')); ?>">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    Contacto
                    <small>Listado</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="/admin/contacto">Contacto</a></li>
                    <li class="breadcrumb-item active">Editar</li>

                </ol>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-12 bg-white">
                <div class="box py-3 px-3">
                    <div class="box-header with-border">
                        <h3 class="box-title">Editar</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <?php echo e(Form::open(['route' => ['contacto.update', $section_id], 'method' => 'PUT', 'files' => true])); ?>


                        <div class="container">
                            <div class="row">
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Título</label>
                                        <textarea name="titulo" id="titulo"><?php echo $es_sections[0]->description; ?></textarea>


                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('titulo')); ?></span>
                                        <?php endif; ?>
                                    </div>


                                </div>
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Descripción</label>
                                        <textarea name="descripcion" id="descripcion"><?php echo $es_sections[1]->description; ?></textarea>

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('descripcion')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Correo</label>
                                        <input name="email_contact" class="form-control" id="email_contact"
                                            value="<?php echo $es_sections[2]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('email_contact')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Celular</label>
                                        <input name="celular_contact" class="form-control" id="celular_contact"
                                            value="<?php echo $es_sections[3]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('celular_contact')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Youtube</label>
                                        <input name="youtube_contact" class="form-control" id="youtube_contact"
                                            value="<?php echo $es_sections[4]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('youtube_contact')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Páginas de Facebook</label>
                                        <textarea class="summer" name="pages_facebook_contact"
                                            id="pages_facebook_contact"><?php echo $es_sections[5]->description; ?></textarea>

                                        <?php if($errors): ?>
                                            <span class="text-danger">
                                                <?php echo e($errors->first('pages_facebook_contact')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <h5 class="text-bold">Seccion formulario</h5>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nombre</label>
                                        <input name="name" class="form-control" id="name" value="<?php echo $es_sections[6]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Ciudad</label>
                                        <input name="city" class="form-control" id="city" value="<?php echo $es_sections[7]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('city')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">País</label>
                                        <input name="country" class="form-control" id="country"
                                            value="<?php echo $es_sections[8]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('country')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Teléfono</label>
                                        <input name="telephone" class="form-control" id="telephone"
                                            value="<?php echo $es_sections[9]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('telephone')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Correo</label>
                                        <input name="email" class="form-control" id="email"
                                            value="<?php echo $es_sections[10]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-11">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Comentario</label>
                                        <input name="comment" class="form-control" id="comment"
                                            value="<?php echo $es_sections[11]->description; ?>">

                                        <?php if($errors): ?>
                                            <span class="text-danger"> <?php echo e($errors->first('comment')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-12 text-right">
                                    <div class="form-group">
                                        <button class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="lang" value="<?php echo e($set_lang); ?>">
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor_assets/summernote/summernote.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#titulo').summernote({
                height: 50,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'black', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });

            $('#descripcion').summernote({
                height: 200,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });

            $('.summer').summernote({
                height: 200,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'ObjectSans-Regular',
                    'ObjectSans-Bold'
                ],
                fontNamesIgnoreCheck: ["ObjectSans-Regular", "ObjectSans-Bold"],
                colors: [
                    ['#1b365d', '#57728b', 'white']
                ],
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript',
                        'subscript', 'clear'
                    ]],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['insert', ['link']],
                    ['view', ['undo', 'redo', 'codeview']]
                ]
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/web/laravel/institutoholistico/resources/views/admin/contacto/edit.blade.php ENDPATH**/ ?>